package ribera.practicapartes.Models;

public enum TipoProfesor {
    jefe_de_estudios,
    profesor
}
